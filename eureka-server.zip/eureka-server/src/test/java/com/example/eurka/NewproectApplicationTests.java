package com.example.eurka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewproectApplicationTests {

	@Test
	void contextLoads() {
	}

}
